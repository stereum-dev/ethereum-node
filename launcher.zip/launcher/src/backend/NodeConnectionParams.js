export class NodeConnectionParams {
  constructor(host, port, username, password, privatekey) {
    this.host = host;
    this.port = port;
    this.username = username;
    this.password = password;
    this.privatekey = privatekey;
  }
}
