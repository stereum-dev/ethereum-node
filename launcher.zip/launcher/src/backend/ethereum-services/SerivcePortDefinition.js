export class ServicePortDefinition {
  constructor(port, protocol, description) {
    this.port = port;
    this.protocol = protocol;
    this.description = description;
  }
}
