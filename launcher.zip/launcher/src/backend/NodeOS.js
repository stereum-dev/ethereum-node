export const nodeOS = {
  ubuntu: "Ubuntu",
  centos: "CentOS",
};
