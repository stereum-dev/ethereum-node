<template>
  <SettingScreen />
</template>
<script setup>
import SettingScreen from "../components/UI/setting-page/SettingScreen.vue";
</script>
