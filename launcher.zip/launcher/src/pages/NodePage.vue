<template>
  <NodeScreen />
</template>
<script setup>
import NodeScreen from "../components/UI/node-page/NodeScreen.vue";
</script>
