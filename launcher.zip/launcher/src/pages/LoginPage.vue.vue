<template>
  <LoginScreen />
</template>
<script setup>
import LoginScreen from "../components/UI/server-management/LoginScreen.vue";
</script>
