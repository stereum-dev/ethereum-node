<template>
  <OneclickScreen />
</template>
<script setup>
import OneclickScreen from "@/components/UI/one-click/OneclickScreen.vue";
</script>
