<template>
  <CreditScreen />
</template>
<script setup>
import CreditScreen from "../components/UI/credit-page/CreditScreen.vue";
</script>
