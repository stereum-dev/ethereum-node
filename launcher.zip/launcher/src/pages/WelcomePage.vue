<template>
  <WelcomeScreen />
</template>

<script setup>
import WelcomeScreen from "../components/UI/welcome-page/WelcomeScreen.vue";
</script>
