<template>
  <EditScreen />
</template>
<script setup>
import EditScreen from "../components/UI/edit-page/EditScreen.vue";
</script>
