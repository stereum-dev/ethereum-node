<template>
  <LangScreen />
</template>

<script setup>
import LangScreen from "../components/UI/language-page/LangScreen.vue";
</script>
