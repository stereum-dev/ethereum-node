<template>
  <CustomScreen />
</template>
<script setup>
import CustomScreen from "@/components/UI/custom-installation/CustomScreen.vue";
</script>
