<template>
  <StakingScreen />
</template>
<script setup>
import StakingScreen from "../components/UI/staking-page/StakingScreen.vue";
</script>
