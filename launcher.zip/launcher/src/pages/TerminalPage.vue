<template>
  <TerminalScreen />
</template>

<script setup>
import TerminalScreen from "@/components/UI/terminal-page/TerminalScreen.vue";
</script>
