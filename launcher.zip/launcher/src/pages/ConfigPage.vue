<template>
  <ConfigScreen />
</template>
<script setup>
import ConfigScreen from "../components/UI/import-config/configScreen.vue";
</script>
