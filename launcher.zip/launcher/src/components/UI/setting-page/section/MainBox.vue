<template>
  <div class="mainBox-setting_parent flex flex-col items-center justify-start h-full w-full p-2">
    <slot></slot>
  </div>
</template>

<style scoped>
.mainBox-setting_parent {
  background: #3a3d40;
}
</style>
