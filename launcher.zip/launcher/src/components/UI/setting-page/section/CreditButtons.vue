<template>
  <div class="credit-btns_parent w-full h-full rounded-md flex justify-between items-center cursor-pointer">
    <slot />
  </div>
</template>
