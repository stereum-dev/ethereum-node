<template>
  <div class="w-44 h-full flex flex-col justify-between items-center fixed right-0 top-0 z-10">
    <div class="grid grid-cols-1 grid-rows-15 w-full h-full px-2 py-4 overflow-hidden border-l border-gray-500 rounded-l-xl bg-[#2e5151]">
      <slot></slot>
    </div>
  </div>
</template>
