<template>
  <MenuBody />
</template>

<script setup>
import MenuBody from "../components/menu/MenuBody.vue";
</script>
