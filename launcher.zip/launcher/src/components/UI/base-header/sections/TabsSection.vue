<template>
  <TabsBody />
</template>

<script setup>
import TabsBody from "../components/tabs/TabsBody.vue";
</script>
