<template>
  <ServiceBody />
</template>

<script setup>
import ServiceBody from "../components/services/ServiceBody.vue";
</script>
