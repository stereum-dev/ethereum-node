<template>
  <div class="w-full h-full col-start-1 col-span-3 row-start-1 row-span-2 bg-[#0F1217] mx-h-[145px] border border-gray-500 rounded-lg">
    Mini Card
  </div>
</template>
