<template>
  <div class="w-full h-full col-start-1 col-span-full row-start-1 row-span-1 bg-[#0F1217] mx-h-[145px] border border-gray-500 rounded-lg">
    Widgets Card
  </div>
</template>
