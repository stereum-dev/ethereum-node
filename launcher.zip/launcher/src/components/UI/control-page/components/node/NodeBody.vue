<template>
  <div class="w-full h-full col-start-7 col-span-full row-start-1 row-span-full grid grid-cols-5 grid-rows-11 items-center">Block Body</div>
</template>
