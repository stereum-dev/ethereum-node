<template>
  <div>Server Card</div>
</template>
