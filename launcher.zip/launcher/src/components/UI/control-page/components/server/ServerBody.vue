<template>
  <div class="w-full h-full col-start-1 col-end-7 grid grid-cols-12 grid-rows-12 items-center p-2">Server Body</div>
</template>
