<template>
  <div class="w-full h-full col-start-1 col-span-full row-start-2 row-span-full items-center">Body</div>
</template>
