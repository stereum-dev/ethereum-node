<template>
  <div class="w-full h-full col-start-1 col-span-full row-start-1 row-span-1 items-center">Header</div>
</template>
