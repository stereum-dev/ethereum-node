<template>
  <NodeBody />
</template>

<script setup>
import NodeBody from "../components/node/NodeBody.vue";
</script>
