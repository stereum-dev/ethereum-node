<template>
  <ServerBody />
</template>

<script setup>
import ServerBody from "../components/server/ServerBody.vue";
</script>
