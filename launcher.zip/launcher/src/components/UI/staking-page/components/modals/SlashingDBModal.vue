<template>
  <staking-custom-modal>
    <template #content> </template>
  </staking-custom-modal>
</template>
