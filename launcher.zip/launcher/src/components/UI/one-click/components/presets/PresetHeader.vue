<template>
  <div class="col-start-1 col-span-full row-start-1 row-span-1 p-1 bg-[#264744] rounded-t-md flex justify-center items-center">
    <span class="text-xl font-bold text-gray-200 uppercase tracking-wider">{{ $t("oneClick.oneClckInstall") }}</span>
  </div>
</template>
