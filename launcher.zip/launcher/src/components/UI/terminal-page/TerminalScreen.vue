<template>
  <base-layout>
    <TerminalBody />
  </base-layout>
</template>

<script setup>
import TerminalBody from "./components/TerminalBody.vue";
</script>
