<template>
  <MenuBody />
</template>

<script setup>
import MenuBody from "../components/MenuBody.vue";
</script>
