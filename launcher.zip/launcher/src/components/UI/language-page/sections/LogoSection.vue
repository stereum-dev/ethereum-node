<template>
  <LogoBody />
</template>

<script setup>
import LogoBody from "../components/LogoBody.vue";
</script>
