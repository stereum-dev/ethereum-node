<template>
  <div class="w-full h-full col-start-1 col-end-8 row-start-1 row-span-full grid grid-cols-12 grid-rows-12">
    <img class="w-full h-full col-start-2 col-end-12 row-start-1 row-span-full" src="/animation/language/heartcore.gif" alt="Logo Anim" />
  </div>
</template>
