<template>
  <base-layout>
    <CreditPanel />
  </base-layout>
</template>
<script setup>
import CreditPanel from "./section/CreditPanel.vue";
</script>
