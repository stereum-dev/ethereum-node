<template>
  <installation-layout>
    <MultiServerScreen />
  </installation-layout>
</template>
<script setup>
import MultiServerScreen from "./MultiServerScreen.vue";
</script>
