<template>
  <div
    class="w-[155px] h-[80px] self-start justify-self-center col-span-1 flex justify-evenly items-center bg-gray-700 rounded-md p-2 opacity-50 pointer-events-none mt-2"
  >
    <div class="w-1/2 flex justify-center items-center">
      <span class="animate-pulse w-14 h-14 rounded-full bg-slate-400"> </span>
    </div>

    <div class="w-1/2 grid grid-cols-3 grid-rows-3 items-center p-1 gap-y-2">
      <span class="animate-pulse col-start-1 col-span-full row-start-1 row-span-1 w-full h-3 rounded-full bg-slate-400"> </span>
      <span class="animate-pulse col-start-1 col-span-full row-start-2 row-span-1 w-full h-3 rounded-full bg-slate-400"> </span>
      <span class="animate-pulse col-start-1 col-span-full row-start-3 row-span-1 w-full h-3 rounded-full bg-slate-400"> </span>
    </div>
  </div>
</template>
