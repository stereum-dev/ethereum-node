<template>
  <div
    class="w-[153px] h-[36px] mt-1 self-start justify-self-center col-span-1 flex justify-between items-center bg-gray-700 rounded-md p-1 opacity-50 pointer-events-none mx-1"
  >
    <div class="w-1/3 flex justify-center items-center">
      <span class="animate-pulse w-6 h-6 rounded-sm bg-slate-400"> </span>
    </div>

    <div class="w-2/3 flex justify-center items-center p-1">
      <span class="animate-pulse col-start-1 col-span-full row-start-1 row-span-1 w-full h-3 rounded-full bg-slate-400"> </span>
    </div>
  </div>
</template>
